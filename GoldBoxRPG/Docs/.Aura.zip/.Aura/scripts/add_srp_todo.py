import re

path = r'I:/Unreal/GoldBoxRPG/Unreal-GoldBox-Engine/GoldBoxRPG/Docs/TODO.md'
with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

new_section = '''

---

## Class-Level SRP — BP_CombatManager (GB-NEW)

57 functions on one Actor. Individual functions are clean after refactor, but the class itself is a god object. Split into ActorComponents:

| Component | Functions | Domain |
|---|---|---|
| TurnFlowComponent | 10 | OnActionComplete, AdvanceToNextCombatant, DispatchTurn, StartPlayerTurn, StartEnemyTurn, FinishEnemyTurn, FindStartCombatant, FindActiveCombatant, BuildInitiativeOrder, SortInitiativeOrder |
| CombatActions | 9 | ExecutePlayerAttack, ResolveSingleAttack, ProcessAttackOutcome, ApplyDamage, EnterTargetSelectMode, EnterMoveMode, ExecuteCombatantMove, EndPlayerTurn, RefreshMoveHighlights |
| StatusEffects | 10 | ApplyCondition, RemoveCondition, HasCondition, TickConditions, CheckDefeat, CheckVictory, IsCombatantIncapacitated, SetMarkerDowned, ResolveMorale, RetreatCharacter |
| CombatSetup | 12 | StartCombat, EndCombat, CleanupCombatState, HandleCombatVictory, HandleCombatDefeat, BuildCombatants, BuildMonsterCombatant, BuildCharacterCombatant, AddCombatantToGrid, SpawnCombatantMarkers, RemoveMarkerForCombatant, DestroyCombatMarkers |
| PostCombat | 5 | AwardAndDistributeXP, PostVictoryMessages, ProcessLootDrops, ShowDefeatScreen, HandleCombatVictory |
| CameraPresentation | 8 | SwitchToCombatCamera, LockPlayerForCombat, EnableCombatInput, TransitionToCombat, RestoreExplorationState, ResetCombatData, MoveMarkerToTile, UpdateCombatantGridPosition |

Shared utilities (stay on Actor): FindCombatantByID, FindMarkerByID.

Cross-component calls (e.g. ProcessAttackOutcome → ResolveMorale) would become component refs or go through the parent Actor.

'''

marker = '## Named CharacterID Constraint'
content = content.replace(marker, new_section + marker)

with open(path, 'w', encoding='utf-8') as f:
    f.write(content)

print('TODO.md updated')
