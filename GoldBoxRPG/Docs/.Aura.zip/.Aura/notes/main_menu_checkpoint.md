# Main Menu Scene — Checkpoint

**Date**: 2026-07-14

## Current State
- **TestDungeon** loads correctly with a test party when entered via "Start New Game" or "Load Game" from WBP_MainMenu.
- BP_GameManager Init flow: `GetCurrentLevelName` → if NOT `L_TestSuite` → `InitialiseGameState` (sets `CurrentGameState=MainMenu`) → `SpawnManagers` → `InitialiseParty` → `InitialiseWorld`.

## Key References
- **WBP_MainMenu**: `/Game/Blueprints/UI/WBP_MainMenu.WBP_MainMenu`
  - Btn_StartNewGame: `SavePartyToDisk` → `OpenLevel("TestDungeon")`
  - Btn_LoadGame: `LoadSavedParty` → `OpenLevel("TestDungeon")`
- **BP_GameManager**: `/Game/Blueprints/Core/BP_GameManager.BP_GameManager` (GameInstance)
- **TestDungeon**: `/Game/Maps/TestDungeon.TestDungeon`
- **MainMenu**: `/Game/Maps/MainMenu.MainMenu` (newly created)

## Config
- `DefaultEngine.ini`: `GameDefaultMap=/Game/Maps/MainMenu.MainMenu`, `EditorStartupMap=/Game/Maps/MainMenu.MainMenu`

## If TestDungeon stops loading correctly
- Check BP_GameManager Init flow hasn't been broken
- Verify WBP_MainMenu button graph connections (SavePartyToDisk / LoadSavedParty → OpenLevel)
- Confirm `OpenLevel` node still targets `TestDungeon` with `Absolute=true`
