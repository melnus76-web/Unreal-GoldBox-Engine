# WBP_CharacterScreen — GB-052 Character Screen

## Objective
Build the tabbed WBP_CharacterScreen widget (Stats / Equipment / Inventory / Spells / Thief Skills) that reads from BP_PartyManager's PartyMembers array, displays full S_Character struct data, and integrates with the existing WBP_ExplorationHUD [V] View Party button.

## Relevant Assets and Quirks
- **Struct:** `/Game/Blueprints/Structs/S_Character` — 64 fields covering ability scores (Might/Acuity/Resolve/Reflex/Vigor/Presence), derived stats (DefenseRating=AC, StrikeNumber=THAC0), saving throws, equipment slots (int32 IDs), inventory (TArray\<int32\>), spell slots L1–L7, thief skills, conditions
- **Data source:** `/Game/Blueprints/Managers/BP_PartyManager` — `PartyMembers` (TArray\<S_Character\>), `OnPartyUpdated` delegate
- **Existing UI:** `/Game/Blueprints/UI/WBP_ExplorationHUD` — dark brown-black palette, parchment gold text, sprite-based buttons, `Btn_View` triggers `[V] View Party`
- **Thief eligibility:** `/Game/Blueprints/Enums/E_CharacterClass` — Rogue and Infiltrator get the Thief Skills tab; all others hide it
- **Conditions:** `/Game/Blueprints/Enums/E_Condition` — 12 values (Normal through Unconscious)
- **No item/spell DataTables exist yet** — equipment, inventory, and spells display raw int32 IDs as placeholder text
- **DataTable:** `/Game/Data/DataTables/DT_TestParty` — 4 test rows (Fighter/Cleric/MagicUser/Thief)
- **Re-roll is character-creation only** — not part of this display screen

## Changes
- `/Game/Blueprints/UI/WBP_CharacterScreen` — (create) Main character sheet widget
- `/Game/Blueprints/UI/WBP_ExplorationHUD` — (edit) Wire Btn_View to spawn WBP_CharacterScreen

## Steps

- [ ] 1. Create WBP_CharacterScreen widget and build the full hierarchy: left panel (party list + close button), right panel (tab row of 5 buttons + WidgetSwitcher with 5 child panels for Stats/Equipment/Inventory/Spells/ThiefSkills). Each tab panel contains its GridPanel/ScrollBox/wrapbox with all label and value TextBlocks. Use the existing dark-brown palette (`(0.04,0.03,0.02,1.0)`) and parchment-gold headers. [depends: none]

- [ ] 2. Add all BindWidget variables to the blueprint — PartyManagerRef (BP_PartyManager object), SelectedIndex (int32), and all ~40 TextBlock/Button/Panel references matching the hierarchy names (Val_Might through Val_ReadLanguages, Btn_TabStats through Btn_TabThief, TabSwitcher, PartyListVBox, ConditionsBox, CharacterNameHeader, etc.). [depends: 1]

- [ ] 3. Implement data-flow functions in the EventGraph: `Initialise(PartyManager)` binds OnPartyUpdated → RefreshPartyList; `RefreshPartyList` clears PartyListVBox and creates one button per party member; `OnCharacterSelected(Index)` sets SelectedIndex and calls PopulateAllTabs. Wire Event Construct → Initialise. [depends: 2]

- [ ] 4. Implement `PopulateAllTabs` — reads PartyMembers[SelectedIndex], breaks the S_Character struct, and populates every Val_* TextBlock: ability scores, HP (CurrentHP/MaxHP formatted), AC (DefenseRating), THAC0 (StrikeNumber), XP, Level (with Level2 dual-class display), all 5 saving throws, all 8 equipment slots (show "—" for 0), inventory grid (per-item TextBlocks in UniformGridPanel), spell slots per level (hide levels with Max==0), thief skill percentages, and conditions (one TextBlock per active condition in ConditionsBox). Also calls UpdateThiefTabVisibility. [depends: 3]

- [ ] 5. Implement tab switching: each Btn_Tab* OnClicked → `OnTabClicked(TabIndex)` which sets TabSwitcher.ActiveWidgetIndex and updates button highlight states (active = button_ready_on sprite, inactive = button sprite). Implement `UpdateThiefTabVisibility` — checks if Class1 or Class2 is Rogue/Infiltrator, sets Btn_TabThief + thief panel visibility accordingly. Implement close button → Remove from Parent. [depends: 4]

- [ ] 6. Wire integration: edit WBP_ExplorationHUD's Btn_View OnClicked to Create Widget (WBP_CharacterScreen) → Add to Viewport → call Initialise(PartyManagerRef). [depends: 5]

## Verify
- Open TestDungeon level, press [V] or click View Party → WBP_CharacterScreen appears
- Fighter row (Thorin) shows: Warden class, Might 17, AC 2, THAC0 50, HP 52/52, no thief tab
- Thief row (Mira) shows: Rogue class, Reflex 18, thief skills (Pick Pockets 30, Climb Walls 85, etc.), Thief Skills tab visible
- Tab switching highlights the active button and shows correct panel
- Close button removes widget from viewport
- Conditions array renders as TextBlocks in the ConditionsBox
