# BP_CombatManager Refactor — Phase 1

## Objective
Decouple the 15-responsibility `BP_CombatManager` monolith by introducing 3 Blueprint Interfaces, event dispatchers, and splitting off `BP_CombatTurnController` + `BP_AttackResolver` as new focused Actor blueprints. Apply all 5 quick wins.

## Changes
- `/Game/Blueprints/Interfaces/BI_CombatTurnProvider` — (create) turn lifecycle events
- `/Game/Blueprints/Interfaces/BI_AttackTarget` — (create) attack resolution contract
- `/Game/Blueprints/Interfaces/BI_MovementLockable` — (create) replaces hard pawn cast
- `/Game/Blueprints/Combat/BP_CombatTurnController` — (create) turn orchestration (~10 funcs)
- `/Game/Blueprints/Combat/BP_AttackResolver` — (create) attack+dmg+conditions (~10 funcs)
- `/Game/Blueprints/Combat/BP_CombatManager` — stripped to thin coordinator (~15 funcs remain)
- `/Game/Blueprints/Dungeon/BP_ExplorerPawn` — add `BI_MovementLockable` interface
- `/Game/Blueprints/Core/BP_GameManager` — spawn new managers, wire new refs

## Relevant Assets and Quirks
- **Spawning pattern:** `BP_GameManager.SpawnManagers` spawns all managers sequentially, then wires `GameManagerRef`, `TextManagerRef`, `PartyManagerRef` on each via direct property sets. New managers must follow this pattern.
- **Direct refs on CombatManager:** `GameManagerRef`, `TextManagerRef`, `PartyManagerRef`, `CombatGridRef`, `EnemyAIRef`, `CombatHUDRef`, `XPManagerRef`, `CombatCameraRef`. New managers will receive the subset they actually need.
- **Dead variable:** `NewVar` (bool) — remove.
- **Misplaced member:** `ResolveAttackResult` (S_AttackResult) — demote to local in `ResolveSingleAttack`.
- **Tick-driven retreat gate:** `EventGraph.ReceiveTick` polls `bPlayerTurnActive AND NOT bMoveMode AND NOT bSelectingTarget` → `RetreatCharacter`. Must become event-driven via `RetreatCurrentCombatant`.
- **Hard pawn cast:** `StartCombat` casts `GetPlayerPawn` → `BP_ExplorerPawn_C` to set `IsMovementLocked`. Replace with `BI_MovementLockable`.
- **`StartCombat` currently reads** `CurrentPlayerTileX/Y` from `GameManagerRef` — TurnController will still need this ref or the grid ref.
- **`BP_CombatGrid`** holds tile occupancy state. PositionController will query it via interface rather than direct ref.
- **No existing interfaces or event dispatchers** in the project — these are the first.

## Quick Wins (step 1 — low risk, no deps)
- Remove `NewVar` from BP_CombatManager variables
- Demote `ResolveAttackResult` from member to local variable in `ResolveSingleAttack`
- Disable Actor Tick on BP_CombatManager, move retreat guard into `RetreatCurrentCombatant` custom event (already wired to `RetreatCharacter`, just remove the tick gate)
- Extract combat log string formatting from `ResolveSingleAttack` into a new pure function `FormatCombatLogMessage` on `BPL_RulesLibrary`

## Steps
- [ ] 1. **Quick Wins:** Remove `NewVar`, demote `ResolveAttackResult` to local, disable Tick + move retreat guard, extract combat log strings to `BPL_RulesLibrary.FormatCombatLogMessage` [depends: none]
- [ ] 2. **Create Interfaces:** Create `BI_MovementLockable` (with `LockMovement`/`UnlockMovement`), `BI_CombatTurnProvider` (with `StartTurn`/`EndTurn`/`OnActionComplete`), `BI_AttackTarget` (with `RequestAttack`/`GetDefenseStats`) via `bp_agent` [depends: 1]
- [ ] 3. **Add BI_MovementLockable to BP_ExplorerPawn:** Implement `LockMovement`/`UnlockMovement` on the pawn, remove the hard cast from `StartCombat` in BP_CombatManager [depends: 2]
- [ ] 4. **Create BP_CombatTurnController:** New Actor BP with functions: `StartCombat`, `StartPlayerTurn`, `StartEnemyTurn`, `EndPlayerTurn`, `OnActionComplete`, `FindStartCombatant`, `DispatchTurn`, `AdvanceToNextCombatant`, `FindActiveCombatant`, `FinishEnemyTurn`. Wire it via `BI_CombatTurnProvider` to CombatManager and EnemyAI [depends: 2]
- [ ] 5. **Create BP_AttackResolver:** New Actor BP with functions: `ExecutePlayerAttack`, `ResolveSingleAttack`, `ProcessAttackOutcome`, `ApplyDamage`, `ApplyCondition`, `ConditionToRemove`, `HasCondition`, `IsCombatantIncapacitated`, `TickConditions`, `CheckVictory`, `CheckDefeat`. Wire via `BI_AttackTarget` [depends: 2]
- [ ] 6. **Strip BP_CombatManager to coordinator:** Remove migrated functions, add event dispatcher listeners to bridge CombatHUD input → TurnController → AttackResolver, update `BP_GameManager.SpawnManagers` to spawn + wire new managers [depends: 4,5]
- [ ] 7. **Add debug logging:** Add `LogTemp` print nodes at each interface boundary (TurnController → CombatManager, AttackResolver → CombatManager) with the calling function name so runtime flow can be traced [depends: 6]

## Verify
- Build: compile all blueprints with no errors
- Runtime: enter combat in TestDungeon, verify full combat loop (initiative roll → player turn → attack → enemy turn → victory/defeat) works identically to pre-refactor behavior
- Check output log for interface-boundary debug messages confirming new delegation flow
- Confirm `BP_CombatManager` Tick is disabled and retreat still works via the custom event
