# Party Management Screen + Roster/Party Fix

## Problem
`SavePartyToDisk` overwrites `SG_CharacterRoster.SavedCharacters` with `PartyMembers`. Created characters go straight into the party instead of a persistent roster. There's no way to manage which roster characters are in the active party.

## Goal
```
Create Character → Roster (SG_CharacterRoster) [persists across sessions]
Party Management   → select from Roster → Party (BP_PartyManager.PartyMembers) [active dungeon party]
```

---

## Step 1: Add Roster variable to BP_PartyManager
- [ ] Open `BP_PartyManager`
- [ ] Add new variable: `RosterCharacters` (TArray of S_Character)
- [ ] Add new variable: `MaxPartySize` (int, default = 6)
- [ ] Compile

## Step 2: Add `LoadRoster` function to BP_PartyManager
- [ ] Create new function: `LoadRoster` (no inputs, no outputs)
- [ ] Logic:
  1. DoesSaveGameExist("CharacterRoster", 0)
  2. If True: LoadGameFromSlot → Cast SG_CharacterRoster → SET RosterCharacters = SavedCharacters
  3. If False: SET RosterCharacters = empty array
- [ ] Compile

## Step 3: Add `AddToRoster` function to BP_PartyManager
- [ ] Create new function: `AddToRoster` (inputs: S_Character NewCharacter)
- [ ] Logic:
  1. If DoesSaveGameExist("CharacterRoster")
     - LoadGameFromSlot → Cast SG_CharacterRoster → Array_Add(NewCharacter) to SavedCharacters → SaveGameToSlot
     - Array_Add(NewCharacter) to RosterCharacters
  2. Else:
     - CreateSaveGameObject(SG_CharacterRoster) → Array_Add(NewCharacter) → SaveGameToSlot
     - Array_Add(NewCharacter) to RosterCharacters
  - [ ] Fire OnPartyUpdated delegate after adding
- [ ] Compile

## Step 4: Add `AddToParty` function to BP_PartyManager
- [ ] Create new function: `AddToParty` (inputs: int32 CharacterID)
- [ ] Logic:
  1. If PartyMembers length >= MaxPartySize → early return
  2. ForEach RosterCharacters: if CharacterID matches → AddCharacter(copy) → Remove from RosterCharacters
  3. SavePartyToDisk (save the updated Party to a separate slot)
  4. Fire OnPartyUpdated
- [ ] Compile

## Step 5: Add `RemoveFromParty` function to BP_PartyManager
- [ ] Create new function: `RemoveFromParty` (inputs: int32 CharacterID)
- [ ] Logic:
  1. Find character in PartyMembers by CharacterID
  2. Add that character back to RosterCharacters
  3. Array_Remove from PartyMembers
  4. Save both to disk
  5. Fire OnPartyUpdated
- [ ] Compile

## Step 6: Fix `SavePartyToDisk` in BP_PartyManager
- [ ] Rename or rewrite: save `PartyMembers` to a separate slot (e.g. "ActiveParty"), not to "CharacterRoster"
- [ ] Save RosterCharacters to SG_CharacterRoster.SavedCharacters → "CharacterRoster" slot
- [ ] Or simplify: one function `SaveAll` that saves both roster and party
- [ ] Compile

## Step 7: Fix WBP_CharacterCreation → AssembleAndAddCharacter
- [ ] Open `WBP_CharacterCreation`
- [ ] In `AssembleAndAddCharacter`, find: `PartyManagerRef → AddCharacter`
- [ ] Replace with: `PartyManagerRef → AddToRoster`
- [ ] Remove the `SavePartyToDisk` call (AddToRoster handles saving)
- [ ] Compile

## Step 8: Create WBP_PartyManagement widget
- [ ] Create new Widget Blueprint: `/Game/Blueprints/UI/WBP_PartyManagement`
- [ ] Layout:
  ```
  CanvasPanel (full screen, semi-transparent black overlay)
    Border (centered, 80% width, 80% height)
      TextBlock "PARTY MANAGEMENT" (header)
      HorizontalBox
        ── LEFT PANEL ──
        Border "RosterPanel" (50% width)
          VerticalBox
            TextBlock "CHARACTER ROSTER"
            ScrollBox
              VerticalBox "RosterList" (populated at runtime)
            Button "Add to Party →"
        ── RIGHT PANEL ──
        Border "PartyPanel" (50% width)
          VerticalBox
            TextBlock "ACTIVE PARTY"
            ScrollBox
              VerticalBox "PartyList" (populated at runtime)
            Button "← Remove"
            TextBlock "PartyGold" (Party Gold: 0)
      Button "CLOSE" (bottom)
  ```
- [ ] Variables needed:
  - `PartyManagerRef` (BP_PartyManager)
  - `SelectedRosterIndex` (int)
  - `SelectedPartyIndex` (int)
- [ ] Compile widget

## Step 9: Add logic to WBP_PartyManagement
- [ ] Create `Initialise(BP_PartyManager)` function:
  - SET PartyManagerRef
  - Call RefreshLists
- [ ] Create `RefreshLists` function:
  - Clear RosterList and PartyList children
  - ForEach PartyManagerRef.RosterCharacters: create entry widget (Name | Race | Class, clickable)
  - ForEach PartyManagerRef.PartyMembers: create entry widget (Name | Class | Level | HP, clickable)
- [ ] Create `OnRosterEntryClicked(int Index)`: SET SelectedRosterIndex
- [ ] Create `OnPartyEntryClicked(int Index)`: SET SelectedPartyIndex
- [ ] Wire `Add to Party` button: call PartyManagerRef.AddToParty(SelectedRosterCharacterID)
- [ ] Wire `Remove` button: call PartyManagerRef.RemoveFromParty(SelectedPartyCharacterID)
- [ ] Bind to PartyManagerRef.OnPartyUpdated → RefreshLists
- [ ] Wire CLOSE button → RemoveFromParent

## Step 10: Wire BP_PartyManager OnPartyUpdated to save
- [ ] In BP_PartyManager EventGraph, add OnPartyUpdated binding that calls save
- [ ] Or ensure AddToParty/RemoveFromParty already save

## Step 11: Wire WBP_MainMenu Btn_AddToParty → WBP_PartyManagement
- [ ] Open WBP_MainMenu EventGraph
- [ ] Find `Btn_AddToParty.OnClicked` event
- [ ] Replace current logic with:
  1. GetGameInstance → Cast BP_GameManager → Get PartyManager
  2. CreateWidget(WBP_PartyManagement) → Initialise(PartyManager)
  3. AddToViewport
- [ ] Compile

## Step 12: Add RemoveFromParty function (if missing)
- [ ] Already handled in Step 5

## Step 13: Test
- [ ] PIE in MainMenu
- [ ] Create Character → appears only in roster, not party
- [ ] Open Party Management → see character in roster
- [ ] Add to Party → moves to Active Party
- [ ] Remove from Party → returns to roster
- [ ] Start New Game → party has correct members
