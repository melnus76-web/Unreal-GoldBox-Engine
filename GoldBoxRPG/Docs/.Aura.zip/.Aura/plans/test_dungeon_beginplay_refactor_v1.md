# TestDungeon BeginPlay + Party/Roster Refactor

## Objective
Clean up TestDungeon's BeginPlay to a single responsibility call, fix the level-transition manager destruction bug, and complete the roster/party separation so Create Character → Roster → Party → Start Game works end-to-end.

## Relevant Assets and Quirks
- **BP_GameManager Init** runs once at game start. `SpawnManagers` spawns 9 managers as actors in the current level. When OpenLevel transitions from MainMenu → TestDungeon, all spawned managers are destroyed. Init never re-runs (it's a GameInstance, not per-level).
- **WBP_PartySlot** still has old code: `ParentRef` typed as `WBP_PartyManagement`, OnClicked calls `PartySlotClicked`/`RosterSlotClicked` directly instead of using the `OnSlotClicked` event dispatcher. This breaks WBP_CharacterScreen which also uses WBP_PartySlot.
- **WBP_CharacterScreen::RefreshPartyList** CreateWidget references old/deleted WBP_PartySlot — shows compile errors.
- **InitialiseTestParty** guard is already in place (checks PartyMembers.Length == 0).

## Changes

1. `/Game/Blueprints/Core/BP_GameManager.BP_GameManager` — add `EnsureManagersReady` function
2. `/Game/Maps/TestDungeon.TestDungeon` — add single-line BeginPlay
3. `/Game/Blueprints/UI/WBP_PartySlot.WBP_PartySlot` — change ParentRef type, simplify OnClicked
4. `/Game/Blueprints/UI/WBP_CharacterScreen.WBP_CharacterScreen` — fix RefreshPartyList

## Steps

- [ ] 1. Add `EnsureManagersReady` to BP_GameManager: check if PartyManager is valid, if not call SpawnManagers → InitialiseParty [depends: none]
- [ ] 2. Wire TestDungeon Level Blueprint BeginPlay: GetGameInstance → Cast to BP_GameManager → EnsureManagersReady [depends: 1]
- [ ] 3. Fix WBP_PartySlot: change ParentRef type from WBP_PartyManagement to `UserWidget`, replace OnClicked Branch+function calls with `Call OnSlotClicked(CharacterIndex)` [depends: none]
- [ ] 4. Fix WBP_CharacterScreen::RefreshPartyList: rebuild with new WBP_PartySlot API (CreateWidget, set SlotName/CharacterIndex/ParentRef(Self), bind OnSlotClicked, AddChild to PartyListVBox) [depends: 3]
- [ ] 5. Test: Create Character → Party Management → add to party → Start Game (TestDungeon loads with party) [depends: 1,2,3,4]

## Verify
- Run TestDungeon directly → test party loads (EnsureManagersReady skips, Init already ran)
- Run MainMenu → Create Character → Party Management → character in roster → ADD TO PARTY → character moves to party → Close → Start Game → TestDungeon loads with party intact, no null ref errors
