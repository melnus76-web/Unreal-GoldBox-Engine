# GB-019: Character Creation Flow

## Objective
Build WBP_CharacterCreation — a multi-step widget using a Widget Switcher that creates a full S_Character struct and adds it to the party via BP_PartyManager.AddCharacter.

## Relevant Assets and Quirks
- `S_Character` struct has all fields already (Might/Vigor/Reflex/Acuity/Resolve/Presence, Level defaults to 1, CharacterID auto-assigned by AddCharacter)
- `BPL_RulesLibrary` has `DiceRoll(3, 6)` for 3d6, `GetAbilityModifier`, `ComputeSavingThrows`, `ComputeMaxHP`
- `BP_PartyManager.AddCharacter()` takes FS_Character, auto-assigns CharacterID
- E_Race: Human/Elf/Dwarf/Gnome/HalfElf/Halfling/HalfOrc — no restrictions for now
- E_CharacterClass: Warden/Skirmisher/Templar/Devout/Sylvan/Adept/Shadowpriest/Rogue/Infiltrator — single class only
- E_Alignment: 9 standard alignments — no class restrictions for now
- Portraits stored as int32 ID (placeholder until 3D polish phase)
- Exceptional Strength: dropped per Threshold System

## Steps
- [ ] 1. Create WBP_CharacterCreation widget: CanvasPanel root with dark background, Widget Switcher named StepSwitcher, 6 child panels (RollStats, ChooseRace, ChooseClass, ChooseAlignment, NameEntry, Confirm). Add Back/Next navigation bar at bottom with Btn_Back, Btn_Next, StepLabel text. Cinzel font styling matching WBP_CharacterScreen.
- [ ] 2. Build Stats Roll panel: 6 stat rows (Might/Vigor/Reflex/Acuity/Resolve/Presence) each with label + value TextBlock + Roll button + re-roll count text. Roll calls BPL_RulesLibrary.DiceRoll(3,6). Track rolls remaining per stat (start 3, disable at 0). Store rolled values as local int32 variables on the widget.
- [ ] 3. Build Race + Class + Alignment panels: each is a UniformGridPanel with buttons per enum value. Selected button highlights gold. Race → class panel populated from E_CharacterClass (all classes, no filter). Alignment shows all 9. Store selections as local enum variables.
- [ ] 4. Build Name Entry panel: EditableTextBox centered on dark panel. On Next: validate non-empty (show "Name required" if blank). Store as local FString variable.
- [ ] 5. Build Portrait placeholder: simple numbered list (1-6) as buttons with thumbnail placeholders. Store selected index as int32.
- [ ] 6. Build Confirm panel: summary text showing all selections (name, race, class, alignment, 6 ability scores, portrait ID). Btn_Confirm assembles S_Character struct: set all fields from locals, Level=1, CurrentHP=MaxHP (call ComputeMaxHP), saving throws from ComputeSavingThrows, SpellSlots from BPL_RulesLibrary formula, CharacterID=0 (auto-assigned). Calls BP_PartyManager.AddCharacter, triggers OnPartyUpdated, removes widget from viewport.
- [ ] 7. Wire StepSwitcher navigation: Btn_Back sets ActiveWidgetIndex -= 1 (disabled on step 0). Btn_Next sets ActiveWidgetIndex += 1 after per-step validation. Update Btn_Back visibility and Btn_Next label per step ("Next" vs "Confirm" on final step).

## Verify
- PIE → open character screen → all 6 ability scores roll 3-18, re-rolls count down, name validation blocks empty, Confirm adds character to party, party panel updates immediately
