# ConfirmPanel — Character Creation Final Step

## Objective
Build the ConfirmPanel (step 6) with a two-column summary of all character choices, three enum-to-text helpers, and a Confirm button that populates an `S_Character` struct and adds it as a new row to `DT_CharacterRoster`.

## Relevant Assets and Quirks
- **WBP_CharacterCreation** — `CurrentStepIndex`, `CharacterName` (Text), `SelectedRace` (byte), `SelectedClass` (byte), `SelectedAlignment` (byte), six stat scores (int), six roll count vars.
- **S_Character** — 60+ fields; only `CharacterName`, `Race`, `Class1`, `Morality`, and 6 stats come from creation. All others default: `Level=1`, `IsPlayerControlled=true`, `CurrentHP=MaxHP` (derived from Vigor or 10), rest zero/empty.
- **Enums** — `E_Race` (Human/Elf/Dwarf/Gnome/HalfElf/Halfling/HalfOrc), `E_CharacterClass` (Warden/Skirmisher/Templar/Devout/Sylvan/Adept/Shadowpriest/Rogue/Infiltrator), `E_Morality` (Righteous/Honorable/Compassionate/Pragmatic/Neutral/Self-Serving/Ruthless).
- **UpdateNavigation** already switches header to "Confirm" and Next button text to "Confirm" on step 6.
- **Next button gate for step 6** is only `ValidateRollStats()` — no additional selection flags needed.
- **DT_CharacterRoster** does not exist yet — must be created using `S_Character` as row struct.
- **CharacterName** on widget is `Text` type; `S_Character.CharacterName` is `FString` — needs `Conv_TextToString`.

## Changes
- `/Game/Data/DataTables/DT_CharacterRoster` — (create) DataTable with `S_Character` row struct
- `/Game/Blueprints/UI/WBP_CharacterCreation` — Add 3 Pure functions, ConfirmPanel widget tree, PopulateConfirmPanel function, modify Next button flow

## Steps

- [ ] 1. Create `DT_CharacterRoster` DataTable at `/Game/Data/DataTables/DT_CharacterRoster` using `S_Character` row struct [depends: none]

- [ ] 2. Create three **Pure** helper functions on WBP_CharacterCreation: `GetRaceDisplayName(InRace: E_Race) → Text`, `GetClassDisplayName(InClass: E_CharacterClass) → Text`, `GetAlignmentDisplayName(InAlignment: E_Morality) → Text`. Each uses Switch on Byte to return the human-readable name (e.g., `E_Race::Human` → "Human", `E_Race::HalfElf` → "Half-Elf"). [depends: none]

- [ ] 3. Build `ConfirmPanel` widget tree inside the existing ConfirmPanel CanvasPanel: a centered Border with dark-brown brush containing a HorizontalBox with two child VerticalBoxes — **LeftColumn** (Name row, divider, Race row, Class row, Alignment row — each as a HorizontalBox with label TextBlock + value TextBlock [Variable]) and **RightColumn** (header "ABILITY SCORES", divider, 6 stat rows — Might through Presence — each label + value TextBlock [Variable]). Use Cinzel font, gold labels, cream values, matching existing panel style. [depends: none]

- [ ] 4. Create `PopulateConfirmPanel` function on WBP_CharacterCreation — reads `CharacterName`, `SelectedRace`, `SelectedClass`, `SelectedAlignment`, and all 6 stat scores; formats stats via `Conv_IntToText`; uses the three enum-to-text helpers from step 2; sets all ConfirmPanel value TextBlocks. Call this from `UpdateNavigation` when `CurrentStepIndex == 6`. [depends: 2, 3]

- [ ] 5. Modify Next button `OnClicked` (EventGraph `ComponentBoundEvent_0`) — add a `Branch` before the gate check: if `CurrentStepIndex == 6`, execute save flow (step 6); else proceed with existing gate + advance logic. [depends: none]

- [ ] 6. Wire save flow on the new branch from step 5: `Make S_Character` struct → set fields from widget vars (CharacterName via `Conv_TextToString`, Race, Class1, Morality, all 6 stats; default `Level=1`, `IsPlayerControlled=true`, `CurrentHP=10`, `MaxHP=10`, remainder 0/empty) → `Add Data Table Row` (Table=DT_CharacterRoster, RowName=CharacterName as String) → `Remove from Parent` to close the widget. Add `Print String` debug logging at each stage. [depends: 1, 5]

## Verify
- Step through character creation to step 6 — ConfirmPanel shows all choices correctly
- Click Confirm — check DT_CharacterRoster in Content Browser has the new row with correct values
- Widget closes after successful save
- If stats weren't rolled (all zero), `ValidateRollStats` returns false and Next button is disabled (existing gate)