# Prevent Skipping Race/Class/Alignment Without Active Selection

## Objective
Block Next button from advancing past steps 1–3 (Race, Class, Alignment) until the player actively clicks a selection button.

## Changes
- `/Game/Blueprints/UI/WBP_CharacterCreation` — Add 3 boolean variables + modify Next button gate + set flags in selection functions

## Relevant Assets and Quirks
- **Next button gate:** `EventGraph` → `K2Node_IfThenElse_13` gated by `BooleanOR(K2Node_CommutativeAssociativeBinaryOperator_2)` — currently ORs `NotEqual(step, 6)` with `ValidateRollStats`
- **SelectRace:** sets `SelectedRace` via `K2Node_VariableSet_0` at function entry
- **SelectClass:** sets `SelectedClass` via `K2Node_VariableSet_0` at function entry
- **SelectAlignment:** sets `SelectedAlignment` via `K2Node_VariableSet_0` at function entry

## Steps
- [ ] 1. Add three boolean variables to WBP_CharacterCreation: `bChoseRace`, `bChoseClass`, `bChoseAlignment` — all `false` by default [depends: none]
- [ ] 2. In `SelectRace` function, add `VariableSet: bChoseRace = true` at end [depends: 1]
- [ ] 3. In `SelectClass` function, add `VariableSet: bChoseClass = true` at end [depends: 1]
- [ ] 4. In `SelectAlignment` function, add `VariableSet: bChoseAlignment = true` at end [depends: 1]
- [ ] 5. In EventGraph Next button handler, extend the `BooleanOR` chain feeding `K2Node_IfThenElse_13`: for steps 1/2/3, also require the corresponding `bChose*` flag to be true [depends: 1,2,3,4]

## Verify
- Press Next on step 1 (Race) without clicking a race button → should not advance
- Click a race button → Next should advance
- Repeat for Class (step 2) and Alignment (step 3)
