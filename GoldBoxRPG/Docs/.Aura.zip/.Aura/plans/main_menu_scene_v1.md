# Main Menu Scene

## Objective
Create a dedicated MainMenu level with a dark atmospheric backdrop that displays the existing `WBP_MainMenu` widget on load, and set it as the project's default startup map.

## Changes
- `/Game/Maps/MainMenu` — (create) new level with minimal dark scene + level blueprint
- `Config/DefaultEngine.ini` — change `GameDefaultMap` and `EditorStartupMap` to `/Game/Maps/MainMenu`
- `/Game/Blueprints/UI/WBP_MainMenu.WBP_MainMenu` — update "Start New Game" / "Load Game" to open `TestDungeon` if not already correct

## Relevant Assets and Quirks
- **BP_GameManager** (`GameInstance`): `Init` calls `InitialiseGameState` (sets `CurrentGameState=MainMenu`) → `SpawnManagers` → `InitialiseParty` → `InitialiseWorld`. This is the main game flow driver and must continue working.
- **WBP_MainMenu**: already fully styled (dark BG, gold Cinzel text, button sprites `button.png`/`button_ready_off.png`/`button_ready_on.png`). All 7 buttons are wired except Options (prints "not yet implemented").
- **Current default map**: `TestDungeon` — game boots directly into dungeon with no menu scene.
- **No existing GameMode class** — everything runs through `BP_GameManager` GameInstance. Use Level Blueprint instead of a GameMode for simplicity.

## Steps
- [ ] 1. Create a new level `/Game/Maps/MainMenu` with a simple dark atmospheric setup: DirectionalLight (dim, warm), SkyAtmosphere, ExponentialHeightFog (dark), and a CineCameraActor facing the center [depends: none]
- [ ] 2. Add Level Blueprint logic to MainMenu: on `BeginPlay`, Create WBP_MainMenu widget → Add to Viewport → Set Input Mode UI Only [depends: 1]
- [ ] 3. Update `Config/DefaultEngine.ini`: set `GameDefaultMap` and `EditorStartupMap` to `/Game/Maps/MainMenu` [depends: none]
- [ ] 4. Verify WBP_MainMenu button flows: ensure "Start New Game" and "Load Game" open `TestDungeon` level (they already do — confirm graph is intact) [depends: none]
- [ ] 5. Take a screenshot of the MainMenu level with the widget displayed to visually verify [depends: 1,2]

## Verify
- Open MainMenu level → WBP_MainMenu appears automatically on Play
- "Start New Game" → saves party → opens TestDungeon
- "Exit Game" → quits
- Editor launches into MainMenu by default
