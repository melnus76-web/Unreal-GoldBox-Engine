# GB-019: Character Creation Flow — Development Guide
## UE5.7 · Blueprints Only · Solo Dev

---

## Overview

**Widget:** `WBP_CharacterCreation`
**Path:** `/Game/Blueprints/UI/WBP_CharacterCreation`
**Pattern:** Widget Switcher with 7 stacked panels
**Output:** Populated `S_Character` struct added to `DT_CharacterRoster` DataTable

### Actual Deviations from Original Spec

| Change | Reason |
|---|---|
| Exceptional Strength dropped | Threshold System removed percentile subsystem |
| No multiclass | Hybrid classes come later as separate classes |
| No race/class restrictions | Deferred until needed |
| Portraits stored as int32 | 3D assets during polish phase |
| Alignment uses E_Morality (7 values) | Simplified from D&D 3×3 grid to GoldBox morality system |
| Dice from BPL_RulesLibrary | No separate BP_DiceSystem exists |
| CharacterName stored as Text in widget | Converted to FString only at save time via Conv_TextToString |
| Selection gates (bChooseRace, etc.) | Added boolean flags for each selection step; Next button uses AND-chain |
| Save to DT_CharacterRoster | New DataTable instead of BP_PartyManager.AddCharacter |

---

## ✅ Step 1 — Widget Shell & Navigation — COMPLETE

### 1a. Widget created

**Status:** ✅ Built.
Saved to `/Game/Blueprints/UI/WBP_CharacterCreation`. Parent: UserWidget.

### 1b. Root structure

**Status:** ✅ Built as designed. Actual names:

```
CanvasPanel "RootCanvas" (dark background R=0.02,G=0.02,B=0.03)
  Border "Background" — fills full canvas
  Border "HeaderBar" — anchored top, full width, H=60, brush R=0.04,G=0.03,B=0.02
    TextBlock "StepLabel" [Variable] — Cinzel 13.5, gold R=0.85,G=0.72,B=0.38
  WidgetSwitcher "StepSwitcher" [Variable] — below header, above navbar
    [0] CanvasPanel "RollStatsPanel" ✅
    [1] CanvasPanel "ChooseRacepanel" ✅
    [2] CanvasPanel "ChooseClassPanel" ✅
    [3] CanvasPanel "ChooseAlignmentPanel" ✅
    [4] CanvasPanel "NameEntryPanel" ✅
    [5] CanvasPanel "PortraitPanel" ❌ (empty placeholder)
    [6] CanvasPanel "ConfirmPanel" 🚧 (widget tree built, logic pending)
  Border "NavBar" — anchored bottom, full width, H=56
    HorizontalBox "NavHBox"
      Button "Btn_Back" [Variable] — Text "Back", Cinzel default, dim gold R=0.85,G=0.72,B=0.3
      SizeBox spacer W=1
      Button "Btn_Next" [Variable] — Text "Next", Cinzel default, gold R=0.85,G=0.72,B=0.38
```

### 1c. Navigation variables

**Status:** ✅ All built.

| Name | Type | Default |
|---|---|---|
| `CurrentStepIndex` | Integer | 0 |

(StepNames array not needed; UpdateNavigation uses a Switch on Int for step labels.)

### 1d. UpdateNavigation function

**Status:** ✅ Built.

Function `UpdateNavigation(CurrentStepIndex: int32)`:
- Switch on `CurrentStepIndex` → sets `LocalStepName` Text: "Roll Ability Scores" / "Choose Race" / "Choose Class" / "Choose Alignment" / "Name" / "Portrait" / "Confirm"
- Sets `StepLabel` Text from `LocalStepName`
- If `CurrentStepIndex == 0`: Btn_Back → Hidden; else: Visible
- If `CurrentStepIndex == 6`: Nextlabel → Text "Confirm"; else: "Next"
- Sets `StepSwitcher.SetActiveWidgetIndex` = `CurrentStepIndex`

### 1e. Button event bindings

**Status:** ✅ Built.

- **Btn_Back OnClicked:** `CurrentStepIndex = Max(step - 1, 0)` → `UpdateNavigation`
- **Btn_Next OnClicked:** Gate check (AND-chain) → True: `CurrentStepIndex = Min(step + 1, 6)` → `UpdateNavigation`

### 1f. Event Construct

**Status:** ✅ Calls `UpdateNavigation` on construct. (PreConstruct also present.)

---

## ✅ Step 2 — Ability Score Roller — COMPLETE

### 2a. Widget variables

**Status:** ✅ All 12 variables exist.

| Name | Type | Default |
|---|---|---|
| `MightScore` | Integer | 0 |
| `VigorScore` | Integer | 0 |
| `ReflexScore` | Integer | 0 |
| `AcuityScore` | Integer | 0 |
| `ResolveScore` | Integer | 0 |
| `PresenceScore` | Integer | 0 |
| `MightRollsRemaining` | Integer | 3 |
| `VigorRollsRemaining` | Integer | 3 |
| `ReflexRollsRemaining` | Integer | 3 |
| `AcuityRollsRemaining` | Integer | 3 |
| `ResolveRollsRemaining` | Integer | 3 |
| `PresenceRollsRemaining` | Integer | 3 |

### 2b. Designer layout

**Status:** ✅ Built.

Border "StatsRollContainer" — centered, W=500, padding 12, dark brown brush R=0.04,G=0.03,B=0.02.
Six rows (Might through Presence), each:
- SizeBox W=130 → TextBlock label (gold, Cinzel 10.5)
- SizeBox W=60 → TextBlock value [Variable] (cream R=0.95,G=0.9,B=0.8, Cinzel 10.5)
- Spacer W=12
- Button [Variable] (button/button_ready_off/button_ready_on sprites) with "Roll" text
- SizeBox W=80 → TextBlock "3 left" [Variable] (dim, Cinzel 9)
- Image divider between rows (T_White_1x1, dark tint)

### 2c. Roll handler logic

**Status:** ✅ All six wired identically.

Pattern for each (e.g. Might):
1. `Greater_IntInt(MightRollsRemaining, 0)` → Branch
2. `DiceRoll(3, 6)` → `MightScore` (VariableSet)
3. `MightRollsRemaining = Subtract(MightRollsRemaining, 1)`
4. `Conv_IntToText(MightScore)` → SetText on Value_Might
5. `FormatText("{0} left", MightRollsRemaining)` → SetText on RollsLeft_Might
6. `EqualEqual(MightRollsRemaining, 0)` → SetIsEnabled(Btn_RollMight, false)

### 2d. ValidateRollStats function

**Status:** ✅ Built.

Pure function → Boolean. Returns true only if all six scores > 0 (chain of BooleanAND over Greater_IntInt checks).

### 2e. Next button gate for step 0

**Status:** ✅ Wired. `(step != 6 OR ValidateRollStats)` ensures step 0 validation only gates step 6. (User confirmed this works correctly despite non-standard OR pattern.)

---

## ✅ Step 3 — Race Selection — COMPLETE

### 3a. Widget variables

| Name | Type | Default |
|---|---|---|
| `SelectedRace` | E_Race (byte) | Human |
| `bChooseRace` | Boolean | False |

### 3b. Designer layout

**Status:** ✅ Built.

Border "RaceContainer" — centered, auto-sized, padding 12, dark brown.
VerticalBox "RaceVBox":
- TextBlock "Header_ChooseRace" — "CHOOSE RACE", gold, Cinzel 12
- Spacer H=12
- UniformGridPanel "RaceGrid" — 3 columns, 3 rows:
  - Human | Elf | Dwarf
  - Gnome | Halfling | Half-Elf
  - (empty) | Half-Orc | (empty)

All 7 buttons use button/button_ready_off/button_ready_on sprites, Text Cinzel 9.75.

### 3c. SelectRace function

**Status:** ✅ Built.

`SelectRace(InRace: E_Race)`:
1. Sets `SelectedRace` = InRace
2. Switch on InRace → highlights selected button text gold, dims others to inactive gray
3. All switch branches converge → sets `bChooseRace = True`

### 3d. Next button gate for step 1

**Status:** ✅ Wired. `(step != 1 OR bChooseRace)` — requires a race selection on step 1.

---

## ✅ Step 4 — Class Selection — COMPLETE

### 4a. Widget variables

| Name | Type | Default |
|---|---|---|
| `SelectedClass` | E_CharacterClass (byte) | Warden |
| `bChooseClass` | Boolean | False |

### 4b. Designer layout

**Status:** ✅ Built.

Border "ClassContainer" — centered, auto-sized, padding 8, dark brown.
UniformGridPanel "ClassGrid" — 3 columns, 3 rows:
- Warden | Skirmisher | Templar
- Devout | Sylvan | Adept
- Shadowpriest | Rogue | Infiltrator

All 9 buttons use same sprite style, Text Cinzel 9.75.

### 4c. SelectClass function

**Status:** ✅ Built. Same pattern as SelectRace: switch on InClass → highlight selected, dim others → set `bChooseClass = True`.

### 4d. Next button gate for step 2

**Status:** ✅ Wired. `(step != 2 OR bChooseClass)`.

---

## ✅ Step 5 — Alignment Selection — COMPLETE

### 5a. Widget variables

| Name | Type | Default |
|---|---|---|
| `SelectedAlignment` | E_Morality (byte) | Righteous |
| `bChooseAlignment` | Boolean | False |

> **Deviation from spec:** Original spec used D&D-style 3×3 E_Alignment grid. Actual implementation uses GoldBox's E_Morality with 7 values: Righteous, Honorable, Compassionate, Pragmatic, Neutral, Self-Serving, Ruthless.

### 5b. Designer layout

**Status:** ✅ Built.

Border "AlignmentContainer" — centered, auto-sized, padding 4/2, dark brown.
UniformGridPanel "AlignmentGrid" — 3 columns, 3 rows:
- Righteous | Honorable | Compassionate
- Pragmatic | Neutral | Self-Serving
- (empty) | Ruthless | (empty)

### 5c. SelectAlignment function

**Status:** ✅ Built (with bug fix).

`SelectAlignment(InAlignment: E_Morality)`:
1. Sets `SelectedAlignment` = InAlignment
2. Switch on InAlignment → highlights selected → sets `bChooseAlignment = True`
3. **Bug fixed:** `MakeStruct` for active color was incorrectly wired to `Inactive Colour`. Now correctly wired to `Active Colour`.

### 5d. Next button gate for step 3

**Status:** ✅ Wired. `(step != 3 OR bChooseAlignment)`.

---

## ✅ Step 6 — Name Entry — COMPLETE

### 6a. Widget variables

| Name | Type | Default |
|---|---|---|
| `CharacterName` | Text | (empty) |

> **Deviation:** Variable is Text type (not String). S_Character.CharacterName is FString — conversion happens at save time via `Conv_TextToString`.

### 6b. Designer layout

**Status:** ✅ Built.

Border "NameContainer" — centered, auto-sized, dark brown.
VerticalBox "NameVBox":
- TextBlock "Header_ChooseName" — "CHOOSE NAME", Cinzel 12, gold, centered
- Spacer H=12
- EditableTextBox "Input_Name" [Variable] — hint "Enter character name...", Cinzel 9.75, dark bg, centered
- Spacer H=12
- HorizontalBox "NameButtonRow" (centered):
  - Button "Btn_RandomName" [Variable] — "Random", Cinzel 9.75
  - Spacer W=12
  - Button "Btn_ClearName" [Variable] — "Clear", Cinzel 9.75

### 6c. GenerateRandomName function

**Status:** ✅ Built (Pure).

Returns Text. Picks random first syllable from 20-element array + random last syllable from 15-element array. Uses `RandomInteger` (Exclusive Max = 20 / 15), concats via `Conv_TextToString → Concat_StrStr → Conv_StringToText`.

### 6d. Event wiring

**Status:** ✅ Built.

- **Btn_RandomName OnClicked:** `GenerateRandomName` → `SetText(Input_Name)` + `VariableSet(CharacterName)`
- **Btn_ClearName OnClicked:** `SetText(Input_Name)` (empty) + `VariableSet(CharacterName)` (empty)
- **Input_Name OnTextChanged:** `GetText(Input_Name)` → `VariableSet(CharacterName)`

### 6e. Next button gate for step 4

**Status:** ✅ Wired. `BooleanOR(step != 4, CharacterName != "")` — name must be non-empty on step 4.

---

## Step 7 — Portrait Selection — NOT STARTED

**Status:** ❌ Empty CanvasPanel placeholder at index 5. No widgets, no variables, no logic.

---

## 🚧 Step 8 — Confirm & Save — IN PROGRESS

### 8a. Widget variables (existing)

All character data already captured via existing variables: `CharacterName`, `SelectedRace`, `SelectedClass`, `SelectedAlignment`, six stat scores.

### 8b. Enum-to-text helper functions

**Status:** ✅ Built (3 Pure functions).

| Function | Input | Output |
|---|---|---|
| `GetRaceDisplayName` | E_Race | Text (e.g. "Human", "Half Elf") |
| `GetClassDisplayName` | E_CharacterClass | Text (e.g. "Warden", "Shadow Priest") |
| `GetAlignmentDisplayName` | E_Morality | Text (e.g. "Righteous", "Self-Serving") |

Each uses Switch on Enum with all cases returning literal Text.

> **Known nit:** GetRaceDisplayName returns "Half Elf" / "Half Orc" without dashes, while race buttons use "Half-Elf" / "Half-Orc". Cosmetic only.

### 8c. Designer layout — ConfirmPanel

**Status:** ✅ Widget tree built. **Two-column layout** (deviates from single-column spec):

```
CanvasPanel "ConfirmPanel"
  Border "ConfirmContainer" — centered, auto-sized, dark brown R=0.04,G=0.03,B=0.02
    HorizontalBox "ConfirmHBox"
      VerticalBox "LeftColumn"
        TextBlock "Header_Summary" — "CHARACTER SUMMARY", gold, Cinzel 9
        Spacer H=12
        Image divider (T_White_1x1, dark tint)
        Spacer H=8
        HorizontalBox "Row_Name"
          TextBlock "Label_Name" — "Name: ", gold, Cinzel 7.88
          TextBlock "Value_Name" [Variable] — gold, Cinzel 7.88
        HorizontalBox "Row_Race"
          TextBlock "Label_Race" — "Race: ", gold
          TextBlock "Value_Race" [Variable] — gold
        HorizontalBox "Row_Class"
          TextBlock "Label_Class" — "Class: ", gold
          TextBlock "Value_Class" [Variable] — gold
        HorizontalBox "Row_Alignment"
          TextBlock "Label_Alignment" — "Alignment: ", gold
          TextBlock "Value_Alignment" [Variable] — gold
      SizeBox spacer W=24
      VerticalBox "RightColumn"
        TextBlock "Header_Stats" — "ABILITY SCORES", gold
        Spacer H=12
        Image divider
        Spacer H=8
        [6 stat rows: Might → Presence]
        Each: label TextBlock (gold) + value TextBlock [Variable] (cream)
```

> **Known issues:** Font sizes are smaller than other panels (9 for header, 7.88 for body vs 12/10.5 elsewhere). Value text colors are gold instead of cream. Cosmetic, not functional.

### 8d. PopulateConfirmPanel function

**Status:** ❌ Not yet built.

Will read all widget variables and set ConfirmPanel value TextBlocks using the three enum helpers + Conv_IntToText for stats. Called from UpdateNavigation when step == 6.

### 8e. DataTable

**Status:** ✅ Created.

`DT_CharacterRoster` at `/Game/Blueprints/Data/DT_CharacterRoster`. Row struct: `S_Character`. Currently empty.

### 8f. Confirm save logic

**Status:** ❌ Not yet wired.

Planned flow:
1. Branch in Btn_Next OnClicked: if `CurrentStepIndex == 6` → save flow; else → normal gate + advance
2. `Make S_Character` struct → set fields from widget vars
3. `Add Data Table Row` (DT_CharacterRoster, RowName = CharacterName → Conv_TextToString)
4. `Remove from Parent` to close widget

### 8g. Default values for unset S_Character fields

Fields not captured during creation default to: `Level=1`, `IsPlayerControlled=true`, `CurrentHP=10`, `MaxHP=10`, `Gender=""`, all equipment/skills/spells/saves zero or empty.

---

## Step 9 — Opening the Widget — NOT STARTED

**Status:** ❌ Not yet implemented. Widget must be opened from a HUD or menu.

---

## Next Button Gate Logic (Complete AND-Chain)

**Status:** ✅ Fully wired.
The entire gate feeds into a single BooleanAND chain before `IfThenElse_13`:

```
Advance if ALL of:
  (step != 6 OR ValidateRollStats)     // Step 0: stats rolled (only gates step 6)
  (step != 1 OR bChooseRace)           // Step 1: race selected
  (step != 2 OR bChooseClass)          // Step 2: class selected
  (step != 3 OR bChooseAlignment)      // Step 3: alignment selected
  (step != 4 OR CharacterName != "")   // Step 4: name non-empty
```

Steps 5 (Portrait) and 6 (Confirm) have no selection gates. Step 6 will branch to save flow instead of advance.

---

## Verification Checklist

- [x] Roll all 6 stats — values appear, rolls remaining decrements
- [x] Roll button disables at 0 remaining
- [x] Next blocked if any stat unrolled (gates step 6 only)
- [x] Race panel highlights selected, defaults to Human
- [x] Class panel shows all 9 classes, defaults to Warden
- [x] Alignment panel shows all 7 moralities, defaults to Righteous
- [x] Name entry with Random/Clear buttons, Next blocked if empty
- [x] Back hidden on step 0, visible on others
- [x] Next says "Confirm" on final step
- [ ] ConfirmPanel populates with correct summary text
- [ ] Confirm → character saved to DT_CharacterRoster → widget closes
- [ ] Portrait panel (placeholder)
- [ ] Widget opened from HUD/menu

---

## Files Created/Modified

| File | Status |
|---|---|
| `/Game/Blueprints/UI/WBP_CharacterCreation` | ✅ Built (steps 0–4 complete, step 6 widget tree done) |
| `/Game/Blueprints/Data/DT_CharacterRoster` | ✅ Created (empty, S_Character row struct) |
| `/Game/Blueprints/Structs/S_Character` | Pre-existing (character data struct, 60+ fields) |
| `/Game/Blueprints/Libraries/BPL_RulesLibrary` | Pre-existing (DiceRoll function) |
| `/Game/Blueprints/Enums/E_Race` | Pre-existing (7 values) |
| `/Game/Blueprints/Enums/E_CharacterClass` | Pre-existing (9 values) |
| `/Game/Blueprints/Enums/E_Morality` | Pre-existing (7 values) |
